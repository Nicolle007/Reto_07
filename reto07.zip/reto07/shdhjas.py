
class MenuItem:
    def __init__(self, nombre, precio):
          self.nombre=nombre
          self.precio=precio


class Sopa(MenuItem):
    def __init__(self, nombre, precio,tipo):
        super().__init__(nombre,precio)
        self.__tipo = tipo  # Atributo privado
    def get_precio(self):
        return self._precio
    def set_precio(self, otro_precio):
        if otro_precio:
            self._precio = otro_precio
    
    def get_tipo(self): # Getter para el atributo tipo
        return self.__tipo

class Bebida(MenuItem):
    def __init__(self, nombre, precio,tipo):
        super().__init__(nombre,precio)
        self.tipo = tipo 
        
    def get_precio(self):
        return self._precio
    def set_precio(self, otro_precio):
        if otro_precio:
            self._precio = otro_precio

class Postre(MenuItem):
    def __init__(self, nombre, precio,tipo):
        super().__init__(nombre,precio)
        self.tipo = tipo # Atributo privado
        
    def get_precio(self):
        return self._precio
    def set_precio(self, otro_precio):
        if otro_precio:
            self._precio = otro_precio

class Fruta(MenuItem):
    def __init__(self, nombre, precio,tipo):
        super().__init__(nombre,precio)
        self.__tipo = tipo # Atributo privado
        
    def get_precio(self):
        return self._precio
    def set_precio(self, otro_precio):
        if otro_precio:
            self._precio = otro_precio

    def get_tipo(self): # Getter para el atributo tipo
        return self.__tipo

class Ensalada(MenuItem):
    def __init__(self, nombre, precio,tipo):
        super().__init__(nombre,precio)
        self.tipo = tipo # Atributo privado
        
    def get_precio(self):
        return self._precio
    def set_precio(self, otro_precio):
        if otro_precio:
            self._precio = otro_precio

class Proteina(MenuItem):
    def __init__(self, nombre, precio,tipo):
        super().__init__(nombre,precio)
        self.tipo = tipo # Atributo privado
        
    def get_precio(self):
        return self._precio
    def set_precio(self, otro_precio):
        if otro_precio:
            self._precio = otro_precio

class Entradas(MenuItem):
    def __init__(self, nombre, precio,tipo):
        super().__init__(nombre,precio)
        self.__tipo = tipo # Atributo privado
        
    def get_precio(self):
        return self._precio
    def set_precio(self, otro_precio):
        if otro_precio:
            self._precio = otro_precio

    def get_lugar(self): # Getter para el atributo lugar
        return self.__tipo

class Adicion(MenuItem):
    def __init__(self, nombre, precio,tipo):
        super().__init__(nombre,precio)
        self.__tipo = tipo # Atributo privado
        
    def get_precio(self):
        return self._precio
    def set_precio(self, otro_precio):
        if otro_precio:
            self._precio = otro_precio

    def get_tipo(self): # Getter para el atributo tipo
        return self.__tipo

class Infantil(MenuItem):
    def __init__(self, nombre, precio,tipo):
        super().__init__(nombre,precio)
        self.tipo = tipo
        
    def get_precio(self):
        return self._precio
    def set_precio(self, otro_precio):
        if otro_precio:
            self._precio = otro_precio
    
class Quesos(MenuItem):
    def __init__(self, nombre, precio,tipo):
        super().__init__(nombre,precio)
        self.__tipo = tipo # Atributo privado
        
    def get_precio(self):
        return self._precio
    def set_precio(self, otro_precio):
        if otro_precio:
            self._precio = otro_precio

    def get_tipo(self): # Getter para el atributo tipo
        return self.__tipo


class Orden:
    global descuento
    descuento=0
    def __init__(self,contenido=list):
      self.contenido=contenido

    def agregar_articulos(self, Item):
        self.contenido.append(Item)

    def total(self):
        suma=0
        for i in self.contenido:
            suma = i._precio + suma
        if descuento!=0:
            suma=suma*descuento
        print(suma)
            

    def descuentos(self,tipo):
        self.tipo = tipo
        match tipo:
            case "Proteina+Ensalada":
                        descuento=0.85
            case "Proteina+Fruta":
                descuento=0.80
            case "Postre+Postre":
                descuento=0.90
            case "Bebida+Adicion":
                descuento=0.90
            case "Infantil+Postre":
                descuento=0.75

    def Items(self):
        for i in self.contenido:
            print(i._nombre)
            
class Pago:
  def __init__(self):
      pass

  def pagar(self, total):
    raise NotImplementedError("Subclases deben implementar el metodo")

class Tarjeta(Pago):
    def __init__(self,tipo):
        super().__init__()
        self.tipo = tipo

    def pagar(self, total):
        print(f"Pagando {total} con tarjeta {self.tipo} ")

class Efectivo(Pago):
  def __init__(self, dinero_entregado):
    super().__init__()
    self.dinero_entregado = dinero_entregado

  def pagar(self, total):
    if total <= self.dinero_entregado:
        cambio=total-self.dinero_entregado
        print(f"Pago realizado en efectivo. Cambio: {cambio}")
    else:
        faltante=total-self.dinero_entregado
        print(f"Faltan {faltante} para el pago.")

# Ejemplo de uso de las clases
pago1 = Tarjeta("debito")
pago2 = Efectivo(100)

pago1.pagar(50)
pago2.pagar(75)

# Sopas
sopa1 = Sopa("Sopa de pollo", 5000, "clara")
sopa2 = Sopa("Sopa de lentejas", 5200, "espesa")
sopa3 = Sopa("Sopa de verduras", 4800, "ligera")

# Bebidas
bebida1 = Bebida("Limonada", 3000, "fría")
bebida2 = Bebida("Chocolate caliente", 3500, "caliente")
bebida3 = Bebida("Jugo de mango", 3200, "fría")

# Postres
postre1 = Postre("Flan", 4000, False)
postre2 = Postre("Helado de vainilla", 4500, True)
postre3 = Postre("Torta de chocolate", 5000, False)

# Frutas
fruta1 = Fruta("Manzana", 2500, "roja")
fruta2 = Fruta("Banano", 2200, "maduro")
fruta3 = Fruta("Uvas", 2700, "verdes")

# Ensaladas
ensalada1 = Ensalada("Ensalada César", 6000, "ligera")
ensalada2 = Ensalada("Ensalada griega", 5800, "fresca")
ensalada3 = Ensalada("Ensalada tropical", 6200, "dulce")

# Proteínas
proteina1 = Proteina("Pollo asado", 10000, "200g")
proteina2 = Proteina("Pescado al horno", 12000, "180g")
proteina3 = Proteina("Carne a la parrilla", 13000, "250g")

# Entradas
entrada1 = Entradas("Pan de ajo", 2500, "mesa")
entrada2 = Entradas("Mini empanadas", 3000, "cocina")
entrada3 = Entradas("Bastones de queso", 3200, "barra")

# Adiciones
adicion1 = Adicion("Papas a la francesa", 4000, "fritas")
adicion2 = Adicion("Arepa", 1500, "asada")
adicion3 = Adicion("Tajadas", 2000, "dulces")

# Infantil
infantil1 = Infantil("Combo dinosaurio", 8500, "hamburguesa, jugo, sorpresa")
infantil2 = Infantil("Caja mágica", 9000, "nuggets, papas, postre")
infantil3 = Infantil("Mini pizza kit", 8000, "pizza personal, jugo")

# Quesos
queso1 = Quesos("Queso mozzarella", 3500, "blando")
queso2 = Quesos("Queso azul", 3800, "fuerte")
queso3 = Quesos("Queso parmesano", 3600, "curado")

orden = Orden([])


#ACTUALIZACION:
import json
class Menu:
    def __init__(self, nombre, alimentos):
        self.nombre=nombre
        self.alimentos=alimentos
     
class pedido:
    def __init__(self):
        self.menu=[]    
    def guardar_archivo_json(self,nombre_archivo):
            objetos_menu = []
            for objeto in self.menu:
                objetos_menu.append({
                    "nombre": objeto.nombre,
                    "precio": objeto.precio,
                    "tipo": objeto.tipo
                })
            with open(nombre_archivo, 'w', encoding='utf-8') as archivo:
                json.dump(objetos_menu, archivo, indent=4) 
    def crear_menu(self):
        print("El menu puede ser de maximo 10 items")
        print("Para guardar el menu escriba g")
        print("para contunuar agregando elementos al menu escriba c")
        g="o"
        while g!="g":
            g=input("Ingresa c o g")
            if g!="g":
                print("1.sopa")
                print("2.bebida")
                print("3.postre")
                print("4.ensalada")
                print("5.fruta") 
                print("6.proteina")
                print("7.ensalada")
                print("8.adicion")
                print("9.queso")
                print("10.infantil")
                clase=input("Ingrese el numero segun el tipo de elemeto que desea crear")
                match clase:
                    case "1":
                        item=lista = list(map(str.strip, input("Ingrese separado por comas: nombre, precio,tipo").split(',')))
                        sopa= Sopa(item[0],item[1],item[2])
                        self.menu.append(sopa)
                    case "2":
                        item=lista = list(map(str.strip, input("Ingrese separado por comas: nombre, precio,tipo").split(',')))
                        sopa= Bebida(item[0],item[1],item[2])
                        self.menu.append(sopa)
                    case "3":
                        item=lista = list(map(str.strip, input("Ingrese separado por comas: nombre, precio,tipo").split(',')))
                        sopa= Postre(item[0],item[1],item[2])
                        self.menu.append(sopa)
                    case "4":
                        item=lista = list(map(str.strip, input("Ingrese separado por comas: nombre, precio,tipo").split(',')))
                        sopa= Ensalada(item[0],item[1],item[2])
                        self.menu.append(sopa)
                    case "5":
                        item=lista = list(map(str.strip, input("Ingrese separado por comas: nombre, precio,tipo").split(',')))
                        sopa= Fruta(item[0],item[1],item[2])
                        self.menu.append(sopa)
                    case "6":
                        item=lista = list(map(str.strip, input("Ingrese separado por comas: nombre, precio,tipo").split(',')))
                        sopa= Proteina(item[0],item[1],item[2])
                        self.menu.append(sopa)
                    case "7":
                        item=lista = list(map(str.strip, input("Ingrese separado por comas: nombre, precio,tipo").split(',')))
                        sopa= Ensalada(item[0],item[1],item[2])
                        self.menu.append(sopa)
                    case "8":
                        item=lista = list(map(str.strip, input("Ingrese separado por comas: nombre, precio,tipo").split(',')))
                        sopa= Adicion(item[0],item[1],item[2])
                        self.menu.append(sopa)
                    case "9":
                        item=lista = list(map(str.strip, input("Ingrese separado por comas: nombre, precio,tipo").split(',')))
                        sopa= Quesos(item[0],item[1],item[2])
                        self.menu.append(sopa)
                    case "10":
                        item=lista = list(map(str.strip, input("Ingrese separado por comas: nombre, precio,tipo").split(',')))
                        sopa= Infantil(item[0],item[1],item[2])
                        self.menu.append(sopa)
        self.guardar_archivo_json("menu.json")

print("Bienvenido") 
pedido1=pedido()
pedido1.crear_menu()

                
                
            
        